/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author davi
 */


import java.sql.*;
import javax.swing.*;
import model.Restaurantes;

public class RestauranteDao {

    public void cadastrarLoja(Restaurantes restaurante) {
        try {
            // Conecta ao banco de dados
            Connection con = ConnectionProvider.getCon();

            // Verifica se o CNPJ do restaurante já existe no banco de dados
            String sqlVerificaCnpj = "SELECT cnpj FROM restaurantes WHERE cnpj = ?";
            PreparedStatement stmtVerifica = con.prepareStatement(sqlVerificaCnpj);
            stmtVerifica.setString(1, restaurante.getCnpj());
            ResultSet rs = stmtVerifica.executeQuery();

            if (rs.next()) {
                // CNPJ já cadastrado
                JOptionPane.showMessageDialog(null, "Este CNPJ já está cadastrado!");
            } else {
                // Verifica se o id_usuario existe na tabela users
                String sqlVerificaUsuario = "SELECT id FROM users WHERE id = ?";
                PreparedStatement stmtVerificaUsuario = con.prepareStatement(sqlVerificaUsuario);
                stmtVerificaUsuario.setInt(1, restaurante.getIdUsuario());
                ResultSet rsUsuario = stmtVerificaUsuario.executeQuery();

                if (!rsUsuario.next()) {
                    // O id do usuário não foi encontrado na tabela users
                    JOptionPane.showMessageDialog(null, "ID de usuário inválido!");
                } else {
                    // Insere o novo restaurante
                    String sqlInserir = "INSERT INTO restaurantes(nome, cnpj, endereco, foto, id_usuario) VALUES (?, ?, ?, ?, ?)";
                    PreparedStatement stmtInserir = con.prepareStatement(sqlInserir);

                    stmtInserir.setString(1, restaurante.getNome());
                    stmtInserir.setString(2, restaurante.getCnpj());
                    stmtInserir.setString(3, restaurante.getEndereco());
                    stmtInserir.setBlob(4, restaurante.getFis(), restaurante.getTamanho());
                    stmtInserir.setInt(5, restaurante.getIdUsuario());

                    int confirma = stmtInserir.executeUpdate();

                    if (confirma == 1) {
                        JOptionPane.showMessageDialog(null, "Loja cadastrada com sucesso!");
                    } else {
                        JOptionPane.showMessageDialog(null, "Erro ao cadastrar a loja :(");
                    }

                    stmtInserir.close();
                }

                rsUsuario.close();
                stmtVerificaUsuario.close();
            }

            rs.close();
            stmtVerifica.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Alguma coisa não ocorreu como o previsto, tente mais tarde :(");
        }
    }
   
}
   