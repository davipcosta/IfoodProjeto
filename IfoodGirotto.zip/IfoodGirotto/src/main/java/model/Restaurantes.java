/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author davi
 */
import java.io.FileInputStream;

public class Restaurantes {
    private String nome;
    private String endereco;
    private String cnpj;
    private int id_usuario;
    private FileInputStream fis;
    private int tamanho;

    // Construtor
    public Restaurantes(String nome, String cnpj, String endereco, FileInputStream fis, int tamanho, int id_usuario) {
        this.nome = nome;
        this.endereco = endereco;
        this.cnpj = cnpj;
        this.fis = fis;
        this.tamanho = tamanho;
        this.id_usuario = id_usuario;
    }

    // Getters e Setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public int getIdUsuario() {
        return id_usuario;
    }

    public void setIdUsuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public FileInputStream getFis() {
        return fis;
    }

    public void setFis(FileInputStream fis) {
        this.fis = fis;
    }

    public int getTamanho() {
        return tamanho;
    }

    public void setTamanho(int tamanho) {
        this.tamanho = tamanho;
    }
}

