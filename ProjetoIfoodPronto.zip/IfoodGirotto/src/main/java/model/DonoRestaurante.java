/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author davi
 */


public class DonoRestaurante extends User {
    private Restaurantes restaurante; // Associa um restaurante ao dono

    public DonoRestaurante(int id, String nome, String email, String senha, String numeroTelefone, String cpf, boolean donoRestaurante) {
     
    }
}
