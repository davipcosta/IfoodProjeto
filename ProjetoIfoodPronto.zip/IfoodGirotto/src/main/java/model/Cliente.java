/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;



/**
 *
 * @author davi
 */


    /**
     *
     */
public class Cliente extends User {
    private Pedido pedidos;  // 

    public Cliente(int id, String nome, String email, String senha, String numeroTelefone, String cpf, boolean donoRestaurante) {
    }
    


  }