/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.ifoodgirotto;

import dao.ConnectionProvider;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author davi
 */
public class PaginaAdmin extends javax.swing.JFrame {

    private boolean verify;

    public boolean isVerify() {
        return verify;
    }

    public void setVerificacao(boolean verify) {
        this.verify = verify;
    }
    
    private int idDoUsuario;

    public int getIdDoUsuario() {
        return idDoUsuario;
    }

    public void setIdDoUsuario(int idDoUsuario) {
        this.idDoUsuario = idDoUsuario;
    }
    
    public PaginaAdmin() {
        initComponents();
    }

    public PaginaAdmin(boolean verify, int idDoUsuario) {
        initComponents();
        this.verify = verify;
        this.idDoUsuario = idDoUsuario;
       
    }
    private int getIdDoUsuarioLogado;

    public int getGetIdDoUsuarioLogado() {
        return getIdDoUsuarioLogado;
    }

    public void setGetIdDoUsuarioLogado(int getIdDoUsuarioLogado) {
        this.getIdDoUsuarioLogado = getIdDoUsuarioLogado;
    }
     public void listarLojas() {

        ListarRestaurantes listarRestaurantes = new ListarRestaurantes(verify);
        
        listarRestaurantes.setVerify(verify);

        try {

            Connection con = ConnectionProvider.getCon();
//             
            String sql = "SELECT * FROM restaurantes WHERE id_usuario = ?";

            PreparedStatement stmt = con.prepareStatement(
                    sql,
                    ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY
            );
            
            stmt.setInt(1, idDoUsuario);
            
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                listarRestaurantes.getTxtId().setText(rs.getString("id"));
                listarRestaurantes.getTxtNome().setText(rs.getString("nome"));
                listarRestaurantes.getTxtCnpj().setText(rs.getString("cnpj"));
                listarRestaurantes.getTxtEndereco().setText(rs.getString("endereco"));         
                Blob blob = (Blob) rs.getBlob("foto");
                byte[] img = blob.getBytes(1, (int) blob.length());
                BufferedImage imagem = null;
                try {
                    imagem = ImageIO.read(new ByteArrayInputStream(img));
                } catch (Exception e) {
                    System.out.println(e);
                }

                ImageIcon icone = new ImageIcon(imagem);
                Icon foto = new ImageIcon(icone.getImage().getScaledInstance(listarRestaurantes.getLblImagem().getWidth(),
                        listarRestaurantes.getLblImagem().getHeight(), Image.SCALE_SMOOTH));
                listarRestaurantes.getLblImagem().setIcon(foto);

            }

            listarRestaurantes.getBtnDireita().addActionListener(e -> {

                try {

                    if (rs.next()) {
                        atualizarInterface(listarRestaurantes, rs);
                    } else {
                        JOptionPane.showMessageDialog(null, "Você não tem mais lojas registradas.");
                    }

                } catch (SQLException ex) {
                    System.out.println(ex);
                }

            });

            listarRestaurantes.getBtnEsquerda().addActionListener(e -> {

                try {

                    if (rs.previous()) {
                        atualizarInterface(listarRestaurantes, rs);
                    } else {
                        JOptionPane.showMessageDialog(null, "Você não tem mais lojas registradas.");
                    }

                } catch (SQLException exyz) {
                    System.out.println(exyz);
                }

            });

        } catch (SQLException e) {

            e.printStackTrace();

        }

        listarRestaurantes.setVisible(true);
        listarRestaurantes.pack();
        listarRestaurantes.setLocationRelativeTo(null); // Para abrir sempre no centro da tela
        this.dispose();

    }

    private void atualizarInterface(ListarRestaurantes listarRestaurantes, ResultSet rs) {
        try {
            // Atualiza os campos com os dados do ResultSet
            listarRestaurantes.getTxtId().setText(rs.getString("id"));
            listarRestaurantes.getTxtNome().setText(rs.getString("nome"));
            listarRestaurantes.getTxtCnpj().setText(rs.getString("cnpj"));
            listarRestaurantes.getTxtEndereco().setText(rs.getString("endereco"));
            Blob blob = (Blob) rs.getBlob("foto");
            byte[] img = blob.getBytes(1, (int) blob.length());
            BufferedImage imagem = null;
            try {
                imagem = ImageIO.read(new ByteArrayInputStream(img));
            } catch (Exception ex) {
                System.out.println(ex);
            }

            ImageIcon icone = new ImageIcon(imagem);
            Icon foto = new ImageIcon(icone.getImage().getScaledInstance(
                    listarRestaurantes.getLblImagem().getWidth(),
                    listarRestaurantes.getLblImagem().getHeight(),
                    Image.SCALE_SMOOTH));
            listarRestaurantes.getLblImagem().setIcon(foto);

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblNome = new javax.swing.JLabel();
        btnCadastrar = new javax.swing.JButton();
        btnListarRestaurantes = new javax.swing.JButton();
        btnDeslogar = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 0, 0));

        lblNome.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        lblNome.setText("Bem vindo!");

        btnCadastrar.setBackground(new java.awt.Color(255, 204, 0));
        btnCadastrar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnCadastrar.setText("Cadastrar Restaurante");
        btnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarActionPerformed(evt);
            }
        });

        btnListarRestaurantes.setBackground(new java.awt.Color(255, 204, 0));
        btnListarRestaurantes.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnListarRestaurantes.setText("Restaurantes Registrados");
        btnListarRestaurantes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListarRestaurantesActionPerformed(evt);
            }
        });

        btnDeslogar.setBackground(new java.awt.Color(255, 204, 0));
        btnDeslogar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnDeslogar.setText("Deslogar");
        btnDeslogar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeslogarActionPerformed(evt);
            }
        });

        btnSair.setBackground(new java.awt.Color(255, 204, 0));
        btnSair.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnSair.setText("Sair");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(66, 66, 66)
                        .addComponent(btnListarRestaurantes))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(75, 75, 75)
                        .addComponent(btnCadastrar))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(87, 87, 87)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnSair, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnDeslogar, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(124, 124, 124)
                        .addComponent(lblNome)))
                .addContainerGap(85, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(78, 78, 78)
                .addComponent(lblNome)
                .addGap(50, 50, 50)
                .addComponent(btnCadastrar)
                .addGap(18, 18, 18)
                .addComponent(btnListarRestaurantes)
                .addGap(18, 18, 18)
                .addComponent(btnDeslogar)
                .addGap(18, 18, 18)
                .addComponent(btnSair)
                .addContainerGap(185, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
        // TODO add your handling code here:
        GerenciarRestaurantes gerenciarRestaurantes = new GerenciarRestaurantes(verify, idDoUsuario);

        gerenciarRestaurantes.setVerify(verify);
        gerenciarRestaurantes.setId(idDoUsuario);

        gerenciarRestaurantes.setVisible(true);
        gerenciarRestaurantes.pack();
        gerenciarRestaurantes.setLocationRelativeTo(null); // para abrir sempre no centro da tela
        this.dispose();
    }//GEN-LAST:event_btnCadastrarActionPerformed

    private void btnListarRestaurantesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListarRestaurantesActionPerformed
        // TODO add your handling code here:
       listarLojas();
    }//GEN-LAST:event_btnListarRestaurantesActionPerformed

    private void btnDeslogarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeslogarActionPerformed
        // TODO add your handling code here:
        int a = JOptionPane.showConfirmDialog(null, "Você realmente deseja deslogar?","Selecione",JOptionPane.YES_NO_OPTION);
        if (a == 0){
        Login login = new Login();
        login.setVisible(true);
        login.pack();
        login.setLocationRelativeTo(null); 
        this.dispose(); 
        }
    }//GEN-LAST:event_btnDeslogarActionPerformed

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        // TODO add your handling code here:
        int a = JOptionPane.showConfirmDialog(null, "Você realmente quer fechar o aplicativo?", "Select", JOptionPane.YES_NO_OPTION);
        if(a==0){
        System.exit(0);
        }
    }//GEN-LAST:event_btnSairActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PaginaAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PaginaAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PaginaAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PaginaAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PaginaAdmin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JButton btnDeslogar;
    private javax.swing.JButton btnListarRestaurantes;
    private javax.swing.JButton btnSair;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblNome;
    // End of variables declaration//GEN-END:variables

    public JLabel getLblNome() {
        return lblNome;
    }

    public void setLblNome(JLabel lblNome) {
        this.lblNome = lblNome;
    }


}
