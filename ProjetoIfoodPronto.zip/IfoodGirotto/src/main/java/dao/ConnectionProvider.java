/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import java.sql.*;
/**
 *
 * @author davi
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionProvider {

    public static Connection getCon() {
        try {
            // Defina sua URL de conexão, usuário e senha do banco
            String url = "jdbc:mysql://localhost:3306/dms";
            String user = "root";
            String password = "Da091205@";

            // Carregar o driver do MySQL (caso não tenha sido configurado no classpath)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Estabelece a conexão
            return DriverManager.getConnection(url, user, password);

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
    
}