/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.io.FileInputStream;

public class ProdutoDao {

    public boolean cadastrarProduto(String nome, double preco, String descricao, String tempoPreparo, FileInputStream fis, int tamanho, int idRestaurante) {
        boolean sucesso = false;
        try {
            // Conecta ao banco de dados
            Connection con = ConnectionProvider.getCon();

            // SQL para inserir o produto
            String sql = "INSERT INTO produtos (nome, preco, descricao, tempoPreparo, foto, id_restaurante) VALUES (?, ?, ?, ?, ?, ?)";

            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, nome);
            stmt.setDouble(2, preco);
            stmt.setString(3, descricao);
            stmt.setString(4, tempoPreparo);
            stmt.setBlob(5, fis, tamanho);
            stmt.setInt(6, idRestaurante);

            int confirma = stmt.executeUpdate();

            if (confirma == 1) {
                sucesso = true;
            }

            stmt.close();
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sucesso;
    }
}


