/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import com.mycompany.ifoodgirotto.PaginaAdmin;
import com.mycompany.ifoodgirotto.PaginaCliente;
import java.sql.*;
import javax.swing.*;
import java.awt.Image;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.sql.SQLException;
import java.sql.Blob;
import java.sql.ResultSet;
import model.User;



public class UserDao extends javax.swing.JFrame {
    private boolean verify = true;

    public boolean isVerify() {
        return verify;
    }

    public void setVerify(boolean verify) {
        this.verify = verify;
    }

    public void cadastrar(User user) {
        try {
            Connection con = ConnectionProvider.getCon();

            String sqlVerificaEmail = "SELECT email FROM users WHERE email = ?";
            PreparedStatement stmtVerifica = con.prepareStatement(sqlVerificaEmail);
            stmtVerifica.setString(1, user.getEmail());
            ResultSet rs = stmtVerifica.executeQuery();

            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "Este email já está cadastrado!");
            } else {
                String sqlInserir = "INSERT INTO users(nome, senha, numeroTelefone, email, cpf, donoRestaurante) VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement stmtInserir = con.prepareStatement(sqlInserir);

                stmtInserir.setString(1, user.getNome());
                stmtInserir.setString(2, user.getSenha());
                stmtInserir.setString(3, user.getNumeroTelefone());
                stmtInserir.setString(4, user.getEmail());
                stmtInserir.setString(5, user.getCpf());
                stmtInserir.setBoolean(6, user.isValorBooleano());

                stmtInserir.execute();
                JOptionPane.showMessageDialog(null, "Você foi cadastrado com sucesso!");

                stmtInserir.close();
            }

            rs.close();
            stmtVerifica.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar usuário!");
        }
    }

    public void login(User user) {
        try {
            Connection con = ConnectionProvider.getCon();

            String sql = "SELECT * FROM users WHERE email = ? AND senha = ?";
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, user.getEmail());
            stmt.setString(2, user.getSenha());

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                user.setId(rs.getInt("id"));
                user.setNome(rs.getString("nome"));
                user.setEmail(rs.getString("email"));
                user.setSenha(rs.getString("senha"));
                boolean verificaLojista = rs.getBoolean("donoRestaurante");

                if (verificaLojista) {
                    verify = true;
                    PaginaAdmin lojistaFrame = new PaginaAdmin(verify, user.getId());
                    lojistaFrame.setIdDoUsuario(user.getId());
                    lojistaFrame.setVerificacao(verify);

                    String sqlNome = "SELECT nome FROM users WHERE id = ?";
                    PreparedStatement stmtNome = con.prepareStatement(sqlNome);
                    stmtNome.setInt(1, user.getId());
                    ResultSet rsNome = stmtNome.executeQuery();

                    if (rsNome.next()) {
                        String nomeLojista = rsNome.getString("nome");
                    }

                    lojistaFrame.setVisible(true);
                    lojistaFrame.pack();
                    lojistaFrame.setLocationRelativeTo(null);
                } else {
                    PaginaCliente verRestaurantes = new PaginaCliente();
                    listarLojas(verRestaurantes);
                    verRestaurantes.setVisible(true);
                    verRestaurantes.pack();
                    verRestaurantes.setLocationRelativeTo(null);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Usuário/Senha incorreto");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void listarLojas(PaginaCliente verRestaurantes) {
        try {
            Connection con = ConnectionProvider.getCon();
            String sql = "SELECT id, nome, endereco, cnpj, foto FROM restaurantes";
            PreparedStatement stmt = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                verRestaurantes.getTxtId().setText(rs.getString("id"));
                verRestaurantes.getTxtNome().setText(rs.getString("nome"));
                verRestaurantes.getTxtEndereco().setText(rs.getString("endereco"));
                verRestaurantes.getTxtCnpj().setText(rs.getString("cnpj"));

                Blob blob = (Blob) rs.getBlob("foto");
                byte[] img = blob.getBytes(1, (int) blob.length());
                BufferedImage imagem = null;
                try {
                    imagem = ImageIO.read(new ByteArrayInputStream(img));
                } catch (Exception e) {
                    System.out.println(e);
                }

                ImageIcon icone = new ImageIcon(imagem);
                Icon foto = new ImageIcon(icone.getImage().getScaledInstance(verRestaurantes.getLblImagem().getWidth(),
                        verRestaurantes.getLblImagem().getHeight(), Image.SCALE_SMOOTH));
                verRestaurantes.getLblImagem().setIcon(foto);
            }

            verRestaurantes.getBtnDireita().addActionListener(e -> {
                try {
                    if (rs.next()) {
                        atualizarInterface(verRestaurantes, rs);
                    } else {
                        JOptionPane.showMessageDialog(null, "Não tem mais lojas!");
                    }
                } catch (SQLException ex) {
                    System.out.println(ex);
                }
            });

            verRestaurantes.getBtnEsquerda().addActionListener(e -> {
                try {
                    if (rs.previous()) {
                        atualizarInterface(verRestaurantes, rs);
                    } else {
                        JOptionPane.showMessageDialog(null, "Não tem mais lojas!");
                    }
                } catch (SQLException ex) {
                    System.out.println(ex);
                }
            });

        } catch (SQLException e) {
            e.printStackTrace();
        }

        verRestaurantes.setVisible(true);
        verRestaurantes.pack();
        verRestaurantes.setLocationRelativeTo(null);
        this.dispose();
    }

    private void atualizarInterface(PaginaCliente verRestaurantes, ResultSet rs) {
        try {
            verRestaurantes.getTxtId().setText(rs.getString("id"));
            verRestaurantes.getTxtNome().setText(rs.getString("nome"));
            verRestaurantes.getTxtEndereco().setText(rs.getString("endereco"));
            verRestaurantes.getTxtCnpj().setText(rs.getString("cnpj"));

            Blob blob = (Blob) rs.getBlob("foto");
            byte[] img = blob.getBytes(1, (int) blob.length());
            BufferedImage imagem = null;
            try {
                imagem = ImageIO.read(new ByteArrayInputStream(img));
            } catch (Exception ex) {
                System.out.println(ex);
            }

            ImageIcon icone = new ImageIcon(imagem);
            Icon foto = new ImageIcon(icone.getImage().getScaledInstance(verRestaurantes.getLblImagem().getWidth(),
                    verRestaurantes.getLblImagem().getHeight(), Image.SCALE_SMOOTH));
            verRestaurantes.getLblImagem().setIcon(foto);

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}